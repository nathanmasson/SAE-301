<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Le Fantastique du Velay</title>
    <link/>
    <script src="script.js"></script>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
          <header>
          <div class="navflex">
            <div class="nav1">
              <img src="images/Fichier 2.png" width="20%">
            </div>
            <div class="nav2">
              <a class="accueil" href="index.html"><h1>Le Festival Du Velay</h1></a>
            </div>
            <div class="nav5"></div>
            <div class="nav3">
              <img src="images/Fichier 1.png" width="20%">
            </div>
            <div class="nav4">
              <img src="images/User.png" width="20%">
            </div>
          </div>
          <div class="navflex2">
            <div class="programme">
              <h1>Programme</h1>
            </div>
            <div class="invites">
              <h1>Invites</h1>
            </div>
            <div class="logo">
              <img src="images/logo Couleur.png" width="45%">
            </div>
            <div class="info">
              <h1>Info</h1>
            </div>
            <div class="concours">
              <a class="lien" href="concours.html"><h1>Concours</h1><a>;
            </div>
          </div>
          </div>
        </header>
    <script src="script.js"></script>
  </body>
</html>
